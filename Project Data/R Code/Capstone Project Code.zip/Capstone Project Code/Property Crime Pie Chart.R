# Calculating the Sum of Property Crime Types
total_burglary <- sum(property_crime_data$Burglary, na.rm = TRUE)
total_larceny <- sum(property_crime_data$Larceny, na.rm = TRUE)
total_motor_vehicle_theft <- sum(property_crime_data$`Motor Vehicle Theft`, na.rm = TRUE)

# Creating data frame for Property Crimes Totals
property_crime_totals <- data.frame(
  Crime_Type = c("Burglary", "Larceny", "Motor Vehicle Theft"),
  Total = c(total_burglary, total_larceny, total_motor_vehicle_theft)
)

# Calculating percentages for Pie Chart
property_crime_totals$Percentage <- property_crime_totals$Total / sum(property_crime_totals$Total) * 100

# Creating label legend for Pie Chart
property_crime_totals$Label <- paste0(property_crime_totals$Crime_Type, ": ", format(property_crime_totals$Total, big.mark = ","))

# Calculating the total number of property crimes
total_property_crimes <- sum(property_crime_totals$Total)

# Creating Pie Chart with values and percentages
ggplot(property_crime_totals, aes(x = "", y = Total, fill = Label)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  labs(title = paste("Total Property Crimes: ", format(total_property_crimes, big.mark = ",")),
       x = "", y = "") +
  geom_text(aes(label = paste0(round(Percentage, 1), "%")), 
            position = position_stack(vjust = 0.5), size = ifelse(property_crime_totals$Percentage < 2, 4, 5), # Adjust size for small slices
            vjust = ifelse(property_crime_totals$Percentage < 2, -0.5, 0.5)) + # Move small labels outside the pie
  theme_minimal() +
  theme(axis.text.x = element_blank(), axis.ticks = element_blank()) +
  theme(legend.position = "bottom", plot.title = element_text(hjust = 0.5)) +
  guides(fill = guide_legend(title = NULL))  # Remove "Label" from the legend

# Exporting the Property Crime Pie Chart
ggsave("property_crime_pie_chart.jpeg", width = 8, height = 6, dpi = 300)