library(readxl)
library(ggplot2)

#file_path <- file.choose()
#print(file_path)

# Loading Socio-Economic Data
socio_econ_data <- read_excel("/Users/pedromedina/Desktop/FIU/FIU FALL 2024 TERM/IDC 6940 - Capstone in Data Science/Project Data/Socio-Economic Factors Data/Socio-Economic Factors Data Table.xlsx")

# Loading Violent-Crime Data (By County)
violent_crime_data_by_county <- read_excel("/Users/pedromedina/Desktop/FIU/FIU FALL 2024 TERM/IDC 6940 - Capstone in Data Science/Project Data/State of Florida Crime Data/State of Florida Violent Crime Data (2015 to 2020).xlsx")

# Loading Property-Crime Data (By County)
property_crime_data_by_county <- read_excel("/Users/pedromedina/Desktop/FIU/FIU FALL 2024 TERM/IDC 6940 - Capstone in Data Science/Project Data/State of Florida Crime Data/State of Florida Property Crime Data (2015 to 2020).xlsx")

#Loading Violent-Crime Data (By Region)
violent_crime_data_by_region <- read_excel("/Users/pedromedina/Desktop/FIU/FIU FALL 2024 TERM/IDC 6940 - Capstone in Data Science/Project Data/State of Florida Crime Data/State of Florida Violent Crime Data (2015 to 2020) by Region.xlsx")

#Loading Property-Crime Data (By Region)
property_crime_data_by_region <- read_excel("/Users/pedromedina/Desktop/FIU/FIU FALL 2024 TERM/IDC 6940 - Capstone in Data Science/Project Data/State of Florida Crime Data/State of Florida Property Crime Data (2015 to 2020) by Region.xlsx")


# Preview the data
head(socio_econ_data)
head(violent_crime_data_by_county)
head(property_crime_data_by_county)

# Checking structure of dataå
str(socio_econ_data)
str(violent_crime_data_by_county)
str(property_crime_data_by_county)

# Converts decimals to Percentages (For percentages in Socio-Economic Data Table)
socio_econ_data$`Poverty Rates` <- socio_econ_data$`Poverty Rates` * 100
socio_econ_data$`Employment Rates` <- socio_econ_data$`Employment Rates` * 100
socio_econ_data$`Educational Attainment Levels (Bachelors Degree or Higher)` <- socio_econ_data$`Educational Attainment Levels (Bachelors Degree or Higher)` * 100

#Summary of Crime Data
summary(violent_crime_data_by_county)
summary(property_crime_data_by_county)

object.size(violent_crime_data_by_county)
object.size(property_crime_data_by_county)