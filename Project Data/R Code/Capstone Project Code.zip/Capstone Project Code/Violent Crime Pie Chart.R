# Calculating the Sum of Violent Crime Types
total_murder <- sum(violent_crime_data$Murder, na.rm = TRUE)
total_rape <- sum(violent_crime_data$Rape, na.rm = TRUE)
total_robbery <- sum(violent_crime_data$Robbery, na.rm = TRUE)
total_aggravated_assault <- sum(violent_crime_data$`Aggravated Assault`, na.rm = TRUE)

# Creating data frame for Violent Crimes Totals
violent_crime_totals <- data.frame(
  Crime_Type = c("Murder", "Rape", "Robbery", "Aggravated Assault"),
  Total = c(total_murder, total_rape, total_robbery, total_aggravated_assault)
)

# Calculating percentages for Pie Chart
violent_crime_totals$Percentage <- violent_crime_totals$Total / sum(violent_crime_totals$Total) * 100

# Creating label legend for Pie Chart
violent_crime_totals$Label <- paste0(violent_crime_totals$Crime_Type, ": ", format(violent_crime_totals$Total, big.mark = ","))

# Calculating the total number of violent crimes
total_violent_crimes <- sum(violent_crime_totals$Total)

# Creating Pie Chart with values and percentages
ggplot(violent_crime_totals, aes(x = "", y = Total, fill = Label)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  labs(title = paste("Total Violent Crimes: ", format(total_violent_crimes, big.mark = ",")),
       x = "", y = "") +
  geom_text(aes(label = paste0(round(Percentage, 1), "%")), position = position_stack(vjust = 0.5)) +
  theme_minimal() +
  theme(axis.text.x = element_blank(), axis.ticks = element_blank()) +
  theme(legend.position = "bottom", plot.title = element_text(hjust = 0.5)) +  # Center the title
  guides(fill = guide_legend(title = NULL))  # Remove the "Label" text from the legend

# Exporting the Violent Crime Pie Chart
ggsave("violent_crime_pie_chart.jpeg", width = 8, height = 6, dpi = 300)