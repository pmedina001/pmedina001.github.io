# Load necessary libraries
library(dplyr)
library(ggcorrplot)

# Merging Violent Crime Data Table with Socio-Economic Factors Data Table
violent_combined <- merge(violent_crime_data_by_county, socio_econ_data, by = "County", all = TRUE)

# Merging Property Crime Data Table with Socio-Economic Factors Data Table
property_combined <- merge(property_crime_data_by_county, socio_econ_data, by = "County", all = TRUE)

# Define socio-economic factors columns
socio_econ_cols <- c(
  "Median Household Income", 
  "Poverty Rates", 
  "Employment Rates",
  "Educational Attainment Levels (Bachelors Degree or Higher)", 
  "Housing Units", 
  "Population Density"
)

# Define individual crime type columns for Violent and Property crimes
violent_crime_cols <- c("Murder", "Rape", "Robbery", "Aggravated Assault")
property_crime_cols <- c("Burglary", "Larceny", "Motor Vehicle Theft")

# Filter datasets for Violent Crime
violent_corr_data <- violent_combined %>%
  select(all_of(violent_crime_cols), all_of(socio_econ_cols))

# Filter datasets for Property Crime
property_corr_data <- property_combined %>%
  select(all_of(property_crime_cols), all_of(socio_econ_cols))

# Compute correlations for Violent Crime (Crime Types vs Socio-Economic Factors)
violent_corr <- cor(violent_corr_data[, violent_crime_cols], violent_corr_data[, socio_econ_cols], use = "complete.obs")

# Compute correlations for Property Crime (Crime Types vs Socio-Economic Factors)
property_corr <- cor(property_corr_data[, property_crime_cols], property_corr_data[, socio_econ_cols], use = "complete.obs")

# Plot heatmap for Violent Crime
ggcorrplot(
  violent_corr,
  lab = TRUE,
  title = "Correlations: Violent Crime Types vs Socio-Economic Factors",
  legend.title = "Correlation",
  show.legend = TRUE
)

# Plot heatmap for Property Crime
ggcorrplot(
  property_corr,
  lab = TRUE,
  title = "Correlations: Property Crime Types vs Socio-Economic Factors",
  legend.title = "Correlation",
  show.legend = TRUE
)