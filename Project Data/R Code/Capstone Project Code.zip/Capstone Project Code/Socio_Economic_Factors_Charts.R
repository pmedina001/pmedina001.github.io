library(ggplot2)

summary (socio_econ_data)

# Remove rows with NA in the Region column
socio_econ_data <- socio_econ_data[!is.na(socio_econ_data$Region), ]

# Boxplot for Median Household Income by Region with Centered Title
ggplot(socio_econ_data, aes(x = Region, y = `Median Household Income`, fill = Region)) +
  geom_boxplot() +
  labs(
    title = "Distribution of Median Household Income by Region",
    x = "Region",
    y = "Median Household Income ($)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),  # Centers the title and adjusts size
    axis.text.x = element_text(angle = 45, hjust = 1),  # Rotates x-axis labels if needed
    legend.position = "right"
  ) +
  scale_y_continuous(labels = scales::comma) +
  scale_fill_manual(values = c("Central Florida" = "red", "North Florida" = "green", "South Florida" = "blue"))

# Boxplot for Poverty Rates by Region with Centered Title
ggplot(socio_econ_data, aes(x = Region, y = `Poverty Rates`, fill = Region)) +
  geom_boxplot() +
  labs(
    title = "Distribution of Poverty Rates by Region",
    x = "Region",
    y = "Poverty Rates (%)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),  # Centers the title and adjusts size
    axis.text.x = element_text(angle = 45, hjust = 1),  # Rotates x-axis labels if needed
    legend.position = "right"
  ) +
  scale_y_continuous(
    labels = scales::percent_format(scale = 1),  # Ensures percentages are displayed correctly
    breaks = seq(0, 50, 5)  # Sets breaks on the y-axis from 0% to 50% in increments of 5%
  ) +
  scale_fill_manual(values = c("Central Florida" = "red", "North Florida" = "green", "South Florida" = "blue"))

# Boxplot for Employment Rates by Region with Centered Title
ggplot(socio_econ_data, aes(x = Region, y = `Employment Rates`, fill = Region)) +
  geom_boxplot() +
  labs(
    title = "Distribution of Employment Rates by Region",
    x = "Region",
    y = "Employment Rates (%)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),  # Centers the title and adjusts size
    axis.text.x = element_text(angle = 45, hjust = 1),  # Rotates x-axis labels if needed
    legend.position = "right"
  ) +
  scale_y_continuous(
    labels = scales::percent_format(scale = 1),  # Ensures percentages are displayed correctly
    breaks = seq(0, 100, 10)  # Sets breaks on the y-axis from 0% to 100% in increments of 10%
  ) +
  scale_fill_manual(values = c("Central Florida" = "red", "North Florida" = "green", "South Florida" = "blue"))

# Boxplot for Educational Attainment Levels by Region with Centered Title
ggplot(socio_econ_data, aes(x = Region, y = `Educational Attainment Levels (Bachelors Degree or Higher)`, fill = Region)) +
  geom_boxplot() +
  labs(
    title = "Distribution of Educational Attainment Levels",
    x = "Region",
    y = "Educational Attainment Levels (%)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),  # Centers the title and adjusts size
    axis.text.x = element_text(angle = 45, hjust = 1),  # Rotates x-axis labels if needed
    legend.position = "right"
  ) +
  scale_y_continuous(
    labels = scales::percent_format(scale = 1),  # Ensures percentages are displayed correctly
    breaks = seq(0, 100, 10)  # Sets breaks on the y-axis from 0% to 100% in increments of 10%
  ) +
  scale_fill_manual(values = c("Central Florida" = "red", "North Florida" = "green", "South Florida" = "blue"))

# Summarize data to calculate total housing units by region
housing_totals <- socio_econ_data %>%
  group_by(Region) %>%
  summarize(Total_Housing = sum(`Housing Units`, na.rm = TRUE))

# Create bar chart with proper y-axis scaling
ggplot(housing_totals, aes(x = Region, y = Total_Housing, fill = Region)) +
  geom_bar(stat = "identity") +
  labs(
    title = "Total Housing Units by Region",
    x = "Region",
    y = "Total Number of Housing Units"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),  # Centers the title
    axis.text.x = element_text(angle = 45, hjust = 1)   # Rotates x-axis labels if necessary
  ) +
  scale_y_continuous(
    labels = scales::comma,  # Formats y-axis values with commas
    breaks = seq(0, max(housing_totals$Total_Housing, na.rm = TRUE), 500000)  # Adjust scale as needed
  ) +
  scale_fill_manual(values = c("Central Florida" = "red", "North Florida" = "green", "South Florida" = "blue"))

# Summarize population density by region (Average)
summarized_density <- socio_econ_data %>%
  group_by(Region) %>%
  summarize(Average_Density = mean(`Population Density`, na.rm = TRUE))

# Create bar chart
ggplot(summarized_density, aes(x = Region, y = Average_Density, fill = Region)) +
  geom_bar(stat = "identity") +
  labs(
    title = "Average Population Density by Region",
    x = "Region",
    y = "Average Population Density"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),
    axis.text.x = element_text(angle = 45, hjust = 1)
  ) +
  scale_y_continuous(labels = scales::comma) +
  scale_fill_manual(values = c("Central Florida" = "red", "North Florida" = "green", "South Florida" = "blue"))

